<div>
    <div class="mt-1.5 flex items-center justify-between py-4">
        <div class="shimmer my-2.5 h-[17px] w-[166px]"></div>
        <div class="shimmer h-[17px] w-[58px]"></div>
    </div>

    <div class="grid">
        <div class="flex flex-col gap-2 py-2.5">
            <div class="flex justify-between">
                <div class="shimmer h-[17px] w-[50px]"></div>
                
                <div class="shimmer h-[17px] w-[25px]"></div>
            </div>
            
            <div class="shimmer h-[17px] w-[200px]"></div>
        </div>
        
        <div class="flex flex-col gap-2 py-2.5">
            <div class="flex justify-between">
                <div class="shimmer h-[17px] w-[50px]"></div>
                
                <div class="shimmer h-[17px] w-[25px]"></div>
            </div>
            
            <div class="shimmer h-[17px] w-[200px]"></div>
        </div>
    </div>
</div>
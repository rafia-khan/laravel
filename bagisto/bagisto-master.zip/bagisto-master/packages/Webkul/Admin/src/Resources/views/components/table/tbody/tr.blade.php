<tr {{ $attributes }}>
    {{ $slot }}
</tr>

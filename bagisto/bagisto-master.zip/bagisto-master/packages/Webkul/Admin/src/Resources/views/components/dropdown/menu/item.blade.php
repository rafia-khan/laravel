<li {{ $attributes->merge(['class' => 'cursor-pointer px-5 py-2 text-sm text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-950 ']) }}>
    {{ $slot }}
</li>

@for ($i = 1; $i <= 4; $i++)
    <!-- Infomration -->
    <div class="flex items-center gap-2 border-b p-4 last:border-b-0 dark:border-gray-800">
        <div class="shimmer h-6 w-6"></div>

        <div class="shimmer h-[17px] w-[70px]"></div>
    </div>
@endfor
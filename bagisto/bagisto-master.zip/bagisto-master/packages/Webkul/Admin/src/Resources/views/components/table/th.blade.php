<th {{ $attributes->merge(['scope' => 'col', 'class' => 'whitespace-nowrap px-6 py-4 font-semibold']) }}>
    {{ $slot }}
</th>

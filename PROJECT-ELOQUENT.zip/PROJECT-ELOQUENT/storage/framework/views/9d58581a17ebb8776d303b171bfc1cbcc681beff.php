

<?php $__env->startSection('title'); ?>
    User Detail
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <table class="table table-striped table-borderd"> 
        <tr>
            <th width="80px">Name :</th>
            <td><?php echo e($users->name); ?></td>
        </tr>
        <tr> 
            <th>Email :</th>
            <td><?php echo e($users->email); ?></td>
        </tr>
        <tr> 
            <th>Age :</th>
            <td><?php echo e($users->age); ?></td>
        </tr>
        <tr> 
            <th>City :</th>
            <td><?php echo e($users->city); ?></td>
        </tr>
    </table>
    <a href="<?php echo e(route('user.index')); ?>" class="btn btn-danger">Back</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\PROJECT-ELOQUENT\resources\views/view.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title'); ?>
    Add New User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('user.store')); ?>" method="POST"> 
        <?php echo csrf_field(); ?>
        <div class="mb-3"> 
            <label for="username" class="form-label">User Name</label>
            <input type="text" name="username" class="form-control">
        </div>

        <div class="mb-3"> 
            <label for="useremail" class="form-label">User Email</label>
            <input type="email" name="useremail" class="form-control">
        </div>

        <div class="mb-3"> 
            <label for="userage" class="form-label">User Age</label>
            <input type="number" name="userage" class="form-control">
        </div>

        <div class="mb-3"> 
            <label for="usercity" class="form-label">User City</label>
            <input type="text" name="usercity" class="form-control">
            
        </div>
        <div class="mb-3"> 
            <input type="submit" value="Save" class="btn btn-success">
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\PROJECT-ELOQUENT\resources\views/adduser.blade.php ENDPATH**/ ?>
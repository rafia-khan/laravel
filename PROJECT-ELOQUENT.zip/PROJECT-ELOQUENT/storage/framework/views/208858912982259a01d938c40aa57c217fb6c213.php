

<?php $__env->startSection('title'); ?>
    All Users Data
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-8">
    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-success btn-sm mb-3">Add New</a>
    <table class="table table-striped table-bordered">

        <tr> 
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Age</th>
            <th>City</th>
            <th>View</th>
            <th>Update</th>
            <th>Delete</th>
        </tr>

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr> 
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><?php echo e($user->age); ?></td>
                <td><?php echo e($user->city); ?></td>
                <td><a href="<?php echo e(route('user.show', $user->id)); ?>" class="btn btn-success">View</a></td>
                <td><a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-warning">Update</a></td>
                <td>
                    <form action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                         <button href="" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    
</div>
<div class="mt-4">
    <?php echo e($users->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel\PROJECT-ELOQUENT\resources\views/home.blade.php ENDPATH**/ ?>
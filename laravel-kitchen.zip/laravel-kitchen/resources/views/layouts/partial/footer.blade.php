<footer class="footer">
        <div class="container-fluid">
          <p>All Right Reserved &copy; 2020, Developed By Polytechnic Laravel Batch</p>
        </div>
      </footer>